package com.example.spring_less.lesson5;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserManager userManager = new UserManager();

        String userName;
        String password;
        String email;

        int choice;

        do {
            System.out.println("1. Создать пользователя ");
            System.out.println("2. Вход в систему ");
            System.out.println("3. Выход из системы ");
            System.out.println("4. Вывод информации ");
            System.out.println("5. Смена пароля ");
            System.out.println("6. Выход из меню");
            System.out.println("Выберите действие: ");

            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Введите имя: ");
                    userName = scanner.next();
                    System.out.println("Введите пароль: ");
                    password = scanner.next();
                    System.out.println("Введите почту: ");
                    email = scanner.next();
                    userManager.addTask(userName, password, email);
                    break;
                case 2:
                    System.out.println("Введите почту ");
                    email = scanner.next();
                    System.out.println("Введите пароль ");
                    password = scanner.next();
                    userManager.logIn(email, password);
                    break;
                case 3:
                    userManager.logOut();
                    break;
                case 4:
                    System.out.print("Информация о пользователе: " );
                    userManager.printInfo();
                    break;
                case 5:
                    System.out.println("Введите новый пароль");
                    password = scanner.next();
                    userManager.changePassword(password);
                    break;
                case 6:
                    System.out.println("Выход с программы");
                    break;
                default:
                    System.out.println("Ошибка");
                    break;
            }
        } while (choice != 6);
    }
}
