package com.example.spring_less.lesson5;

import java.sql.Connection;
import java.sql.SQLException;

public class TaskConnection {
    Connection connection;
    public Connection getConn() throws ClassNotFoundException, SQLException {
        String connectionString = "jdbc:mysql://" + localhost + ":" + dbPort + "/" + dbName;

        Class.forName("com.mysql.jdbc.Driver");

        connection = DriverManager.getConnection(connectionString, dbUser, dbPass);

        return connection;
    }
}
