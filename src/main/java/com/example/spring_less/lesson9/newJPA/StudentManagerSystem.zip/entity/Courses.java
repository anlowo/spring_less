package com.example.spring_less.lesson9.newJPA.entity;

public class Courses {
}
